package facades;

import DTO.CustomerDTO;
import entities.BankCustomer;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 *
 * Rename Class to a relevant name Add add relevant facade methods
 */
public class FacadeExample {

    private static FacadeExample instance;
    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
    
    //Private Constructor to ensure Singleton
    private FacadeExample() {}
    public static void main(String[] args) {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
    FacadeExample facade = FacadeExample.getFacadeExample(emf);
    BankCustomer bC = new BankCustomer("laars", "larsen");
    facade.addCustomer(bC);
    }
    
    /**
     * 
     * @param _emf
     * @return an instance of this facade class.
     */
    public static FacadeExample getFacadeExample(EntityManagerFactory _emf) {
        if (instance == null) {
            emf = _emf;
            instance = new FacadeExample();
        }
        return instance;
    }

    private EntityManager getEntityManager() {
        return emf.createEntityManager();
    }
    CustomerDTO getCustomerByID(int id){
        EntityManager em = emf.createEntityManager();
        try{
            BankCustomer bC = em.find(BankCustomer.class,(long)id);
            CustomerDTO cDTO = new CustomerDTO(bC);
            return cDTO;
        }finally {
            em.close();
        }
    }
    List<CustomerDTO> getCustomerByName(String name){
         EntityManager em = emf.createEntityManager();
        try{
            TypedQuery<CustomerDTO> query = 
                       em.createQuery("Select c from BANKCUSTOMER c where c.FIRSTNAME = :FirstName",CustomerDTO.class);
            query.setParameter("FirstName", name);
            return query.getResultList();
        }finally {
            em.close();
        }
    }
    
    BankCustomer addCustomer(BankCustomer cust){
        EntityManager em = emf.createEntityManager();
        try{
            em.getTransaction().begin();
            em.persist(cust);
            em.getTransaction().commit();
            return cust;

        }finally {
            em.close();
        }
    }
    List<BankCustomer> getAllBankCustomers(){
        EntityManager em = emf.createEntityManager();
        try{
            TypedQuery<BankCustomer> query = 
                       em.createQuery("Select c from BANKCUSTOMER c",BankCustomer.class);
            return query.getResultList();
        }finally {
            em.close();
        }
    }


}
