/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DTO;

import entities.BankCustomer;

/**
 *
 * @author jenso
 */
public class CustomerDTO {
    Long customerID;
    String fullName; 
    String accountNumber;
    double balance;

    public CustomerDTO(BankCustomer bC) {
        this.customerID = bC.getId();
        this.fullName = bC.getFirstName() + " " +bC.getLastName();
        this.accountNumber = bC.getAccountNumber();
        this.balance = bC.getBalance();
    }
    

    
}
