/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author jenso
 */
public class MakeTestData {
    private static MakeTestData instance;
    private static EntityManagerFactory emf;
    
    public static void main(String[] args) {    
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");
        MakeTestData MTD = instance.getMakeTestData(emf);
        BankCustomer bC = MTD.addCustomer(new BankCustomer("KAJ", "OLSEN"));
        BankCustomer bC1 = MTD.addCustomer(new BankCustomer("Nina", "OLSEN"));
    }

    /**
     *
     * @param emf
     * @return
     */
    public static MakeTestData getMakeTestData(EntityManagerFactory _emf) {
        if (instance == null) {
            emf = _emf;
            instance = new MakeTestData();
        }
        return instance;
    }
    
    public BankCustomer addCustomer (BankCustomer bC){
        EntityManager em = emf.createEntityManager();
        try{
            em.getTransaction().begin();
            em.persist(bC);
            em.getTransaction().commit();
            return bC;

        }finally {
            em.close();
        }
    }
}
