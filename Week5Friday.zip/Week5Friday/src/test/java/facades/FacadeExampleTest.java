/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facades;

import DTO.CustomerDTO;
import entities.BankCustomer;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.fail;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
//import org.junit.After;
//import org.junit.AfterClass;
//import org.junit.Before;
//import org.junit.BeforeClass;
////import org.junit.jupiter.api.Test;
//import static org.junit.Assert.*;

/**
 *
 * @author thomas
 */
public class FacadeExampleTest {
    private static final EntityManagerFactory ENF = Persistence.createEntityManagerFactory("pu");
    private static final FacadeExample FE = FacadeExample.getFacadeExample(ENF);
    public FacadeExampleTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
//        Add code to setup entities for test before running any test methods
    }
    
    @AfterAll
    public static void tearDownClass() {
//        Clean up database after test is done or use a persistence unit with drop-and-create to start up clean on every test
    }
    
    @BeforeEach
    public void setUp() {
//        Put the test database in a proper state before each test is run
    }
    
    @AfterEach
    public void tearDown() {
//        Remove any data after each test was run
    }

    /**
     * Test a method here.
     */
    @Test
    public void testSomeMethod() {
        
    }
    @Test
    public void testGetCustomerByID() {
        CustomerDTO cDTO = FE.getCustomerByID(1);
        assert cDTO!= null;
    }
    @Test
    public void testAddCustomer(){
        BankCustomer bC = new BankCustomer("Kaj", "Olsen");
        FE.addCustomer(bC);
        CustomerDTO cDTO = FE.getCustomerByID(3);
        assert cDTO != null;
        
    }
    @Test
    public void testGetAllCustomers(){
        List<BankCustomer> bCL = FE.getAllBankCustomers();
        assertFalse(bCL.isEmpty());
    }
    @Test
    public void testGetCustomerByName(){
        List<CustomerDTO> cDTOL = FE.getCustomerByName("Kaj");
        assertFalse(cDTOL.isEmpty());
    }
}
