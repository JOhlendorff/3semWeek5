# week1-simple-jpa-rest

Simple code to show how to start up with jpa
