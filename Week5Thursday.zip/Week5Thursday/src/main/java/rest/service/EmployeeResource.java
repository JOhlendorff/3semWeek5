package rest.service;

import com.google.gson.Gson;
import dto.EmployeeDTO;
import entities.Employee;
import facades.EmployeeFacade;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


@Path("employee")
public class EmployeeResource {

    EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu"); ; 
    EmployeeFacade facade =  EmployeeFacade.getEmployeeFacade(emf);

    @GET
    @Produces({MediaType.APPLICATION_JSON})
    public String demo() {
        return "{\"msg\":\"succes\"}";
    }
    
    @GET
    @Path("all")
    @Produces
    public String employeeGetAll(){
        List<Employee> eList = facade.getAllEmployees();
        ArrayList<EmployeeDTO> eDTOList = new ArrayList();
        for (Employee employee : eList) {
            eDTOList.add(new EmployeeDTO(employee));
        }
        return new Gson().toJson(eDTOList);
    }
    
    @GET
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public String employeeGetID(@PathParam("id") int id){
        Employee employee = facade.findEmployeeByID(id);
        return new Gson().toJson(new EmployeeDTO(employee));
    }@GET
    @Path("name/{name}")
    @Produces(MediaType.APPLICATION_JSON)
    public String employeeGetName(@PathParam("name") String name){
        List<Employee> employeeList = facade.findEmployeeByName(name);
        ArrayList<EmployeeDTO> eDTOList = new ArrayList();
            for (Employee employee : employeeList) {
                eDTOList.add(new EmployeeDTO(employee));
            }
        return new Gson().toJson(eDTOList);
    }
    @GET
    @Path("highestpaid")
    @Produces(MediaType.APPLICATION_JSON)
    public String employeeHighestPay(){
        List<Employee> eList = facade.getHighestPay();
        ArrayList<EmployeeDTO> eDTOList = new ArrayList();
        for (Employee employee : eList) {
            eDTOList.add(new EmployeeDTO(employee));
        }
        return new Gson().toJson(eDTOList);
    }
    

    @POST
    @Consumes({MediaType.APPLICATION_JSON})
    public void create(Employee entity) {
        throw new UnsupportedOperationException();
    }
    
    @PUT
    @Path("/{id}")
    @Consumes({MediaType.APPLICATION_JSON})
    public void update(Employee entity, @PathParam("id") int id) {
        throw new UnsupportedOperationException();
    }
}
