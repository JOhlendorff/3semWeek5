package facades;

import entities.Employee;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 *
 * Rename Class to a relevant name Add add relevant facade methods
 */
public class EmployeeFacade {

    private static EmployeeFacade instance;
    private static EntityManagerFactory emf;
    
    //Private Constructor to ensure Singleton
    private EmployeeFacade() {}
    
    public static void main(String[] args) {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("pu");      
    EmployeeFacade facade = EmployeeFacade.getEmployeeFacade(emf);
    Employee b1 = facade.addEmployee(new Employee("Aske", "Teglholmens Østkaj", 10));
    //Find book by ID

    }
    /**
     * 
     * @param _emf
     * @return an instance of this facade class.
     */
    public static EmployeeFacade getEmployeeFacade(EntityManagerFactory _emf) {
        if (instance == null) {
            emf = _emf;
            instance = new EmployeeFacade();
        }
        return instance;
    }
    
    public Employee findEmployeeByID(int id){
         EntityManager em = emf.createEntityManager();
        try{
            Employee emp = em.find(Employee.class,(long)id);
            return emp;
        }finally {
            em.close();
        }
    }
    
    public List<Employee> findEmployeeByName(String name){
         EntityManager em = emf.createEntityManager();
        try{
            TypedQuery<Employee> query = 
                       em.createQuery("Select c from Employee c where c.name = :name",Employee.class);
            query.setParameter("name", name);
            return query.getResultList();
        }finally {
            em.close();
        }
    }
    public List<Employee> getAllEmployees(){
         EntityManager em = emf.createEntityManager();
        try{
            TypedQuery<Employee> query = 
                       em.createQuery("Select c from Employee c",Employee.class);
            return query.getResultList();
        }finally {
            em.close();
        }
    }
    
    public List<Employee> getHighestPay(){
         EntityManager em = emf.createEntityManager();
        try{
            int salary = em.createQuery("SELECT MAX(e.salary) FROM Employee e", Integer.class).getSingleResult();
            TypedQuery<Employee> query = 
                       em.createQuery("Select c from Employee c where c.salary = :salary",Employee.class);
            query.setParameter("salary", salary);
            return query.getResultList();
        }finally {
            em.close();
        }
    }
    
    public Employee addEmployee(Employee e){
        EntityManager em = emf.createEntityManager();
        try{
            em.getTransaction().begin();
            em.persist(e);
            em.getTransaction().commit();
            return e;

        }finally {
            em.close();
        }
    }

    private EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

}
